# Vantex Client for MCEE
(Maybe) the first and only hacked client for MCEE

## ❓ How to install
1. Press "C" when you are in a world. 
2. Select `Microsoft Makecode`
3. Click on the + to make a new project
4. Click on the "JS" button at the top
5. Copy the code in main.js
6. Paste the code into the editor on MCEE
