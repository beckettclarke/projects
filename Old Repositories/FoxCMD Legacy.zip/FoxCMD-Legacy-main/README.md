# 🦊 FoxCMD Legacy
A command line tool
<br>ℹ️ It is recommended to install [the newest FoxCMD](https://github.com/ItsFoxDev/FoxCMD), as it recieves updates, and has more features.
## ⬇️ Install legacy
Simply run this command in your terminal
``` 
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/ItsFoxDev/FoxCMD-Legacy/main/install.sh)" 
```
